﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lesson_17.ElvesDLL
{
    public class BladeDancer
    {
        public void PrepareSword()
        {
            Console.WriteLine("ГОТОВЛЮСЬ");
        }

        public void SingSong()
        {
            Console.WriteLine("ЛА-ЛА-ЛА");
        }

        public void Hit()
        {
            Console.WriteLine("ХЬЯ");
        }
    }
}
