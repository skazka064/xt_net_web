﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lesson_17.ElvesDLL
{
    public class ElfMage
    {
        public void CastSpell()
        {
            Console.WriteLine("ОЙ ЩАС БАБАХНЕТ!");
        }
    }
}
